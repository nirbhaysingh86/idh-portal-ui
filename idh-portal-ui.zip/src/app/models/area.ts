export class Area {
  constructor(public areaId = 0, public subjectAreaName = '' ) { }
}
