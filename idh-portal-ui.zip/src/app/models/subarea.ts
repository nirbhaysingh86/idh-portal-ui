export class SubArea {
  constructor(public subAreaId = 0, public areaId = 0, public subjectSubAreaName = '') { }
}
