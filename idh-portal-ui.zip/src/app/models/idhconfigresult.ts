export class IdhConfig {
  constructor(public subjectAreaName = '', public subjectSubAreaName = '', public sourceSystemCode = '', public objectName = '', public resourceName = '', public user = '', public lastUpdated = '') { }
}
