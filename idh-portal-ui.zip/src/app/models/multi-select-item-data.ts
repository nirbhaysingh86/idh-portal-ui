export interface ItemData {
  item: string;
  selected: boolean;
}
