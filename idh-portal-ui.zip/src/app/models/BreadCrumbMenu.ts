export class BreadCrumbMenu {
  constructor(public routerText = 0, public routerLink = '' ) { }
}
